//Self invoking functions
(function(name){
    console.log('Hey i am cool'+name)
})('shital');