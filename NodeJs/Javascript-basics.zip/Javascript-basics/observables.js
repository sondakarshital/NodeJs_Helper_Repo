

const promise = new Promise((resolve,reject) => {
    console.log('I was called!');
});




