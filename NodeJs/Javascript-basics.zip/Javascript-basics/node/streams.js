var fs = require('fs');
var data = '';
// var readStream = fs.createReadStream('input.txt');

// readStream.setEncoding('UTF8');

// readStream.on('data',(chunk)=>{
//     data+=chunk;
// });

// readStream.on('end',()=>{
//     console.log('data',data);
//     var writeStream = fs.createWriteStream('input1.txt');
    
    
//     writeStream.write(data,'UTF8');
    
//     writeStream.end();
    
//     writeStream.on('finish',()=>{
//         console.log('finished writing');
//     });
    
//     writeStream.on('error',(err)=>{
//         console.log('err',err)
//     });
// });

// readStream.on('error',(err)=>{
//     console.log('err',err)
// });

var readStream = fs.createReadStream('input.txt');
var writeStream = fs.createWriteStream('input1.txt');

readStream.pipe(writeStream);

console.log("Program Ended");




